<template>
  <router-view></router-view>
</template>

<style>
/* Reset margin default browser */
body {
  margin: 0;
  padding: 0;
  background-color: #f8f9fd;
}
</style>